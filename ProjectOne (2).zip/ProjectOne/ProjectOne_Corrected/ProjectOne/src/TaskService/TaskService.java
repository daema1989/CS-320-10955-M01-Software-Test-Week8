/*************************
 * Name: Todd Johnson
 * Course: CS-320
 * Date: 06/12/2025
 *************************/
package TaskService;

import java.util.*;

public class TaskService {
    private final Map<String, Task> taskMap = new HashMap<>();

    public void addTask(Task task) {
        if (taskMap.containsKey(task.getTaskId())) {
            throw new IllegalArgumentException("Duplicate task ID");
        }
        taskMap.put(task.getTaskId(), new Task(task.getTaskId(), task.getName(), task.getDescription()));
    }

    public boolean deleteTask(String taskId) {
        return taskMap.remove(taskId) != null;
    }

    public void updateTask(Task task) {
        Task existing = taskMap.get(task.getTaskId());
        if (existing == null) {
            throw new NoSuchElementException("Task not found");
        }
        existing.setName(task.getName());
        existing.setDescription(task.getDescription());
    }

    public Task getTaskById(String taskId) {
        Task task = taskMap.get(taskId);
        return task != null ? new Task(task.getTaskId(), task.getName(), task.getDescription()) : null;
    }
}
