/*************************
 * Name: Todd Johnson
 * Course: CS-320
 * Date: 06/12/2025
 *************************/
package AppointmentService;

import java.util.HashMap;
import java.util.Map;
import java.util.NoSuchElementException;

public class AppointmentService {
    private final Map<String, Appointment> appointments = new HashMap<>();

    public void addAppointment(Appointment appointment) {
        if (appointments.containsKey(appointment.getAppointmentId()))
            throw new IllegalArgumentException("Duplicate appointment ID.");
        appointments.put(appointment.getAppointmentId(), appointment);
    }

    public boolean deleteAppointment(String appointmentId) {
        if (!appointments.containsKey(appointmentId))
            throw new NoSuchElementException("Appointment not found.");
        appointments.remove(appointmentId);
        return true;
    }

    public Appointment getAppointmentById(String appointmentId) {
        Appointment original = appointments.get(appointmentId);
        if (original == null) return null;
        return new Appointment(
            original.getAppointmentId(),
            original.getAppointmentDate(),
            original.getDescription()
        );
    }
}
