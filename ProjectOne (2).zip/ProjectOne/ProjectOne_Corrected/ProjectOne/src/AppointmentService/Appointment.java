/*************************
 * Name: Todd Johnson
 * Course: CS-320
 * Date: 06/12/2025
 *************************/
package AppointmentService;

import java.util.Date;

public class Appointment {
    private final String appointmentId;
    private Date appointmentDate;
    private String description;

    public Appointment(String appointmentId, Date appointmentDate, String description) {
        if (appointmentId == null || appointmentId.length() > 10)
            throw new IllegalArgumentException("Invalid appointment ID.");
        if (appointmentDate == null || appointmentDate.before(new Date()))
            throw new IllegalArgumentException("Appointment date must be in the future.");
        if (description == null || description.length() > 50)
            throw new IllegalArgumentException("Invalid description.");

        this.appointmentId = appointmentId;
        setAppointmentDate(appointmentDate);
        setDescription(description);
    }

    public String getAppointmentId() {
        return appointmentId;
    }

    public Date getAppointmentDate() {
        return new Date(appointmentDate.getTime());
    }

    public void setAppointmentDate(Date appointmentDate) {
        if (appointmentDate == null || appointmentDate.before(new Date()))
            throw new IllegalArgumentException("Appointment date must be in the future.");
        this.appointmentDate = new Date(appointmentDate.getTime());
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        if (description == null || description.length() > 50)
            throw new IllegalArgumentException("Invalid description.");
        this.description = description;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (!(obj instanceof Appointment)) return false;
        Appointment other = (Appointment) obj;
        return appointmentId.equals(other.appointmentId);
    }

    @Override
    public int hashCode() {
        return appointmentId.hashCode();
    }
}
