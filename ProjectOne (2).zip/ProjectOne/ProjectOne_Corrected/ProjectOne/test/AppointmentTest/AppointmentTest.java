/*************************
 * Name: Todd Johnson
 * Course: CS-320
 * Date: 06/12/2025
 *************************/
package AppointmentTest;


import java.util.Calendar;
import java.util.Date;

import org.junit.jupiter.api.Test;

import AppointmentService.Appointment;

import static org.junit.jupiter.api.Assertions.*;

public class AppointmentTest {

    private Date getFutureDate() {
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.DATE, 1); // Tomorrow
        return cal.getTime();
    }

    private Date getTodayDate() {
        Calendar cal = Calendar.getInstance();
        return cal.getTime();
    }

    @Test
    public void testAppointment_withValidId_idIsSetCorrectly() {
        Appointment appointment = new Appointment("123", getFutureDate(), "Dental cleaning");
        assertEquals("123", appointment.getAppointmentId());
    }

    @Test
    public void testAppointment_withValidDescription_descriptionIsSetCorrectly() {
        Appointment appointment = new Appointment("123", getFutureDate(), "Dental cleaning");
        assertEquals("Dental cleaning", appointment.getDescription());
    }

    @Test
    public void testAppointment_withValidDate_dateIsSet() {
        Appointment appointment = new Appointment("123", getFutureDate(), "Dental cleaning");
        assertNotNull(appointment.getAppointmentDate());
    }

    @Test
    public void testAppointment_withTodayDate_isValid() {
        Appointment appointment = new Appointment("TODAY", getTodayDate(), "Checkup today");
        assertEquals("TODAY", appointment.getAppointmentId());
    }

    @Test
    public void testAppointment_withNullId_throwsException() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment(null, getFutureDate(), "Checkup");
        });
    }

    @Test
    public void testAppointment_withPastDate_throwsException() {
        Date pastDate = new Date(System.currentTimeMillis() - 100000); // 100 sec in past
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("123", pastDate, "Checkup");
        });
    }

    @Test
    public void testAppointment_withLongDescription_throwsException() {
        String longDescription = "This is a very long appointment description that exceeds fifty characters.";
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("123", getFutureDate(), longDescription);
        });
    }
}
