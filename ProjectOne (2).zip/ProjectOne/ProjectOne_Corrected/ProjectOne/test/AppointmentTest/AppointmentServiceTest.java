/*************************
 * Name: Todd Johnson
 * Course: CS-320
 * Date: 06/12/2025
 *************************/
package AppointmentTest;


import java.util.Calendar;
import java.util.Date;
import java.util.NoSuchElementException;

import org.junit.jupiter.api.Test;

import AppointmentService.Appointment;
import AppointmentService.AppointmentService;

import static org.junit.jupiter.api.Assertions.*;

public class AppointmentServiceTest {

    private Date getFutureDate() {
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.DATE, 2);
        return cal.getTime();
    }

    @Test
    public void testAddAppointment_withValidData_appointmentIsStored() {
        AppointmentService service = new AppointmentService();
        Appointment appt = new Appointment("A1", getFutureDate(), "Eye exam");

        service.addAppointment(appt);

        Appointment stored = service.getAppointmentById("A1");
        assertEquals(appt, stored);
    }

    @Test
    public void testAddAppointment_withDuplicateId_throwsException() {
        AppointmentService service = new AppointmentService();
        Appointment appt1 = new Appointment("DUP", getFutureDate(), "One");
        Appointment appt2 = new Appointment("DUP", getFutureDate(), "Two");

        service.addAppointment(appt1);

        assertThrows(IllegalArgumentException.class, () -> service.addAppointment(appt2));
    }

    @Test
    public void testDeleteAppointment_withExistingId_appointmentIsRemoved() {
        AppointmentService service = new AppointmentService();
        Appointment appt = new Appointment("Del1", getFutureDate(), "Removal");

        service.addAppointment(appt);
        boolean deleted = service.deleteAppointment("Del1");

        assertTrue(deleted);
    }

    @Test
    public void testDeleteAppointment_withNonExistentId_throwsException() {
        AppointmentService service = new AppointmentService();
        assertThrows(NoSuchElementException.class, () -> service.deleteAppointment("MissingID"));
    }
}
