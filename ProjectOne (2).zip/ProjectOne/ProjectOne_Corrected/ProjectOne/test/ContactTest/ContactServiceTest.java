/*************************
 * Name: Todd Johnson
 * Course: CS-320
 * Date: 06/12/2025
 *************************/
package ContactTest;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;

import java.util.NoSuchElementException;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import ContactService.Contact;
import ContactService.ContactService;

/*************************
 * Name: Todd Johnson
 * Course: CS-320
 * Date: 06/12/2025
 *************************/
public class ContactServiceTest {

    private ContactService service;

    private static final String ID = "001";
    private static final String FIRST = "John";
    private static final String LAST = "Doe";
    private static final String PHONE = "1234567890";
    private static final String ADDRESS = "123 Main St";

    @BeforeEach
    public void setUp() {
        service = new ContactService();
    }

    @Test
    public void testAddContact_withValidContact_shouldSucceed() {
        Contact contact = new Contact(ID, FIRST, LAST, PHONE, ADDRESS);
        service.addContact(contact);
        Contact result = service.getContactById(ID);
        assertEquals(FIRST, result.getFirstName());
    }

    @Test
    public void testAddContact_withDuplicateId_shouldFail() {
        Contact contact = new Contact(ID, FIRST, LAST, PHONE, ADDRESS);
        service.addContact(contact);
        assertThrows(IllegalArgumentException.class, () -> service.addContact(contact));
    }

    @Test
    public void testDeleteContact_withExistingId_shouldRemoveContact() {
        Contact contact = new Contact(ID, FIRST, LAST, PHONE, ADDRESS);
        service.addContact(contact);
        service.deleteContact(ID);
        assertNull(service.getContactById(ID));
    }

    @Test
    public void testDeleteContact_withNonexistentId_shouldThrowException() {
        assertThrows(NoSuchElementException.class, () -> service.deleteContact("999"));
    }

    @Test
    public void testUpdateContact_withValidData_shouldUpdateSuccessfully() {
        service.addContact(new Contact(ID, FIRST, LAST, PHONE, ADDRESS));
        service.updateContact(ID, "Jane", null, null, null);
        assertEquals("Jane", service.getContactById(ID).getFirstName());
    }

    @Test
    public void testUpdateContact_withInvalidPhone_shouldThrowException() {
        service.addContact(new Contact(ID, FIRST, LAST, PHONE, ADDRESS));
        assertThrows(IllegalArgumentException.class, () ->
            service.updateContact(ID, null, null, "invalid", null));
    }

    @Test
    public void testGetContactById_withMissingContact_shouldReturnNull() {
        assertNull(service.getContactById("nope"));
    }
}
