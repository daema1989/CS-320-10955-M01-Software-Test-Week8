
/*************************
 * Name: Todd Johnson
 * Course: CS-320
 * Date: 06/12/2025
 *************************/
package ContactTest;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

import org.junit.jupiter.api.Test;

import ContactService.Contact;

public class ContactTest {

    private static final String VALID_ID = "12345";
    private static final String VALID_FIRST = "Jane";
    private static final String VALID_LAST = "Doe";
    private static final String VALID_PHONE = "1234567890";
    private static final String VALID_ADDRESS = "456 Elm Street";

    @Test
    public void testCreateContact_withValidFields_shouldSucceed() {
        Contact contact = new Contact(VALID_ID, VALID_FIRST, VALID_LAST, VALID_PHONE, VALID_ADDRESS);
        assertEquals(VALID_FIRST, contact.getFirstName());
    }

    @Test
    public void testCreateContact_withNullId_shouldFail() {
        assertThrows(IllegalArgumentException.class, () ->
            new Contact(null, VALID_FIRST, VALID_LAST, VALID_PHONE, VALID_ADDRESS));
    }

    @Test
    public void testCreateContact_withLongId_shouldFail() {
        assertThrows(IllegalArgumentException.class, () ->
            new Contact("12345678901", VALID_FIRST, VALID_LAST, VALID_PHONE, VALID_ADDRESS));
    }

    @Test
    public void testCreateContact_withNullFirstName_shouldFail() {
        assertThrows(IllegalArgumentException.class, () ->
            new Contact(VALID_ID, null, VALID_LAST, VALID_PHONE, VALID_ADDRESS));
    }

    @Test
    public void testCreateContact_withLongFirstName_shouldFail() {
        assertThrows(IllegalArgumentException.class, () ->
            new Contact(VALID_ID, "ThisNameIsTooLong", VALID_LAST, VALID_PHONE, VALID_ADDRESS));
    }

    @Test
    public void testCreateContact_withNullLastName_shouldFail() {
        assertThrows(IllegalArgumentException.class, () ->
            new Contact(VALID_ID, VALID_FIRST, null, VALID_PHONE, VALID_ADDRESS));
    }

    @Test
    public void testCreateContact_withLongLastName_shouldFail() {
        assertThrows(IllegalArgumentException.class, () ->
            new Contact(VALID_ID, VALID_FIRST, "ThisLastNameTooLong", VALID_PHONE, VALID_ADDRESS));
    }

    @Test
    public void testCreateContact_withNullPhone_shouldFail() {
        assertThrows(IllegalArgumentException.class, () ->
            new Contact(VALID_ID, VALID_FIRST, VALID_LAST, null, VALID_ADDRESS));
    }

    @Test
    public void testCreateContact_withInvalidPhoneLength_shouldFail() {
        assertThrows(IllegalArgumentException.class, () ->
            new Contact(VALID_ID, VALID_FIRST, VALID_LAST, "1234567", VALID_ADDRESS));
    }

    @Test
    public void testCreateContact_withNullAddress_shouldFail() {
        assertThrows(IllegalArgumentException.class, () ->
            new Contact(VALID_ID, VALID_FIRST, VALID_LAST, VALID_PHONE, null));
    }

    @Test
    public void testSetFirstName_withInvalidValue_shouldFail() {
        Contact contact = new Contact(VALID_ID, VALID_FIRST, VALID_LAST, VALID_PHONE, VALID_ADDRESS);
        assertThrows(IllegalArgumentException.class, () -> contact.setFirstName(null));
    }

    @Test
    public void testSetLastName_withInvalidValue_shouldFail() {
        Contact contact = new Contact(VALID_ID, VALID_FIRST, VALID_LAST, VALID_PHONE, VALID_ADDRESS);
        assertThrows(IllegalArgumentException.class, () -> contact.setLastName(null));
    }

    @Test
    public void testSetPhone_withInvalidFormat_shouldFail() {
        Contact contact = new Contact(VALID_ID, VALID_FIRST, VALID_LAST, VALID_PHONE, VALID_ADDRESS);
        assertThrows(IllegalArgumentException.class, () -> contact.setPhone("bad"));
    }

    @Test
    public void testSetAddress_withTooLong_shouldFail() {
        Contact contact = new Contact(VALID_ID, VALID_FIRST, VALID_LAST, VALID_PHONE, VALID_ADDRESS);
        assertThrows(IllegalArgumentException.class, () ->
            contact.setAddress("This address is way too long for the system to accept because it's over 30 characters."));
    }
}
