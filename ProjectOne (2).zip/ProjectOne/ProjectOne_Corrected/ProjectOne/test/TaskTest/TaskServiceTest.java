/*************************
 * Name: Todd Johnson
 * Course: CS-320
 * Date: 06/12/2025
 *************************/
package TaskTest;

import org.junit.jupiter.api.Test;

import TaskService.Task;
import TaskService.TaskService;

import static org.junit.jupiter.api.Assertions.*;

public class TaskServiceTest {

    private static final String TASK_ID = "001";
    private static final String TASK_NAME = "Test Task";
    private static final String TASK_DESC = "Do something important";

    @Test
    public void testAddTask_withValidData_taskAddedSuccessfully() {
        TaskService service = new TaskService();
        Task task = new Task(TASK_ID, TASK_NAME, TASK_DESC);

        service.addTask(task);
        Task result = service.getTaskById(TASK_ID);

        assertEquals(task, result);
    }

    @Test
    public void testDeleteTask_withExistingId_taskDeletedSuccessfully() {
        TaskService service = new TaskService();
        Task task = new Task(TASK_ID, TASK_NAME, TASK_DESC);

        service.addTask(task);
        boolean deleted = service.deleteTask(TASK_ID);

        assertTrue(deleted);
    }

    @Test
    public void testUpdateTask_withValidData_taskUpdatedSuccessfully() {
        TaskService service = new TaskService();
        service.addTask(new Task(TASK_ID, "Old Name", "Old Desc"));

        Task updated = new Task(TASK_ID, "New Name", "New Description");
        service.updateTask(updated);

        assertEquals(updated, service.getTaskById(TASK_ID));
    }

    @Test
    public void testGetTaskById_withInvalidId_returnsNull() {
        TaskService service = new TaskService();
        Task result = service.getTaskById("notFound");

        assertNull(result);
    }
}
