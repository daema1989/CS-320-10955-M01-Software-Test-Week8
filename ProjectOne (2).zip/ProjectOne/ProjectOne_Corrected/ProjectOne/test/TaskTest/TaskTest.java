/*************************
 * Name: Todd Johnson
 * Course: CS-320
 * Date: 06/12/2025
 *************************/
package TaskTest;

import org.junit.jupiter.api.Test;

import TaskService.Task;

import static org.junit.jupiter.api.Assertions.*;

public class TaskTest {

    @Test
    public void testTask_withValidData_setsFieldsCorrectly() {
        Task task = new Task("123", "Test", "Description");
        assertEquals("123", task.getTaskId());
        assertEquals("Test", task.getName());
        assertEquals("Description", task.getDescription());
    }

    @Test
    public void testSetName_withValidValue_updatesName() {
        Task task = new Task("123", "Old", "Desc");
        task.setName("New Name");
        assertEquals("New Name", task.getName());
    }

    @Test
    public void testSetDescription_withValidValue_updatesDescription() {
        Task task = new Task("123", "Name", "Old Desc");
        task.setDescription("New Description");
        assertEquals("New Description", task.getDescription());
    }

    @Test
    public void testTask_withInvalidId_throwsException() {
        assertThrows(IllegalArgumentException.class, () -> new Task(null, "Name", "Desc"));
        assertThrows(IllegalArgumentException.class, () -> new Task("12345678901", "Name", "Desc")); // too long
    }

    @Test
    public void testTask_withInvalidNameOrDescription_throwsException() {
        assertThrows(IllegalArgumentException.class, () -> new Task("123", null, "Desc"));
        assertThrows(IllegalArgumentException.class, () -> new Task("123", "Name", null));
        assertThrows(IllegalArgumentException.class, () -> new Task("123", "ThisNameIsWayTooLongToBeValid", "Desc"));
        assertThrows(IllegalArgumentException.class, () -> new Task("123", "Name", "x".repeat(51))); // too long
    }

    @Test
    public void testEquals_withMatchingFields_returnsTrue() {
        Task a = new Task("123", "Task", "Work");
        Task b = new Task("123", "Task", "Work");
        assertEquals(a, b);
    }

    @Test
    public void testEquals_withDifferentFields_returnsFalse() {
        Task a = new Task("123", "Task", "Work");
        Task b = new Task("123", "Different", "Work");
        assertNotEquals(a, b);
    }
}
