package ContactTest;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import ContactService.Contact;
import ContactService.ContactService;

import java.util.NoSuchElementException;

public class ContactServiceTest {

    private ContactService service;
    private static final String ID = "001";
    private static final String FIRST = "John";
    private static final String LAST = "Doe";
    private static final String PHONE = "1234567890";
    private static final String ADDRESS = "123 Main St";

    @BeforeEach
    public void setup() {
        service = new ContactService();
    }

    @Test
    public void testAddContact_withValidContact_shouldSucceed() {
        Contact contact = new Contact(ID, FIRST, LAST, PHONE, ADDRESS);
        service.addContact(contact);
        assertEquals(FIRST, service.getContactById(ID).getFirstName());
    }

    @Test
    public void testAddContact_withDuplicateId_shouldFail() {
        Contact contact = new Contact(ID, FIRST, LAST, PHONE, ADDRESS);
        service.addContact(contact);
        assertThrows(IllegalArgumentException.class, () -> service.addContact(contact));
    }

    @Test
    public void testDeleteContact_withExistingId_shouldRemoveContact() {
        Contact contact = new Contact(ID, FIRST, LAST, PHONE, ADDRESS);
        service.addContact(contact);
        service.deleteContact(ID);
        assertNull(service.getContactById(ID));
    }

    @Test
    public void testDeleteContact_withNonExistentId_shouldThrowException() {
        assertThrows(NoSuchElementException.class, () -> service.deleteContact("nope"));
    }

    @Test
    public void testUpdateContact_withValidContact_shouldUpdateData() {
        service.addContact(new Contact(ID, FIRST, LAST, PHONE, ADDRESS));
        Contact updated = new Contact(ID, "Jane", "Smith", PHONE, ADDRESS);
        service.updateContact(updated);
        assertEquals("Jane", service.getContactById(ID).getFirstName());
        assertEquals("Smith", service.getContactById(ID).getLastName());
    }

    @Test
    public void testUpdateContact_withNonExistentId_shouldThrowException() {
        Contact contact = new Contact("999", "Jane", "Doe", PHONE, ADDRESS);
        assertThrows(NoSuchElementException.class, () -> service.updateContact(contact));
    }

    @Test
    public void testGetContactById_withMissingId_shouldReturnNull() {
        assertNull(service.getContactById("notfound"));
    }
}
