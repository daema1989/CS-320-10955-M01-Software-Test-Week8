package ContactTest;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import ContactService.Contact;

public class ContactTest {
    @Test
    public void testValidContact() {
        Contact c = new Contact("001", "John", "Doe", "1234567890", "123 Main St");
        assertEquals("001", c.getContactId());
        assertEquals("John", c.getFirstName());
    }

    @Test
    public void testInvalidIdTooLong() {
        assertThrows(IllegalArgumentException.class, () ->
            new Contact("12345678901", "John", "Doe", "1234567890", "123 Main St"));
    }

    @Test
    public void testInvalidPhoneTooShort() {
        assertThrows(IllegalArgumentException.class, () ->
            new Contact("001", "John", "Doe", "1234", "123 Main St"));
    }
}
