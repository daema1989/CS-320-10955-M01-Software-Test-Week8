package AppointmentTest;

import static org.junit.jupiter.api.Assertions.*;
import java.util.Date;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import AppointmentService.Appointment;
import AppointmentService.AppointmentService;

public class AppointmentServiceTest {
    private AppointmentService service;

    @BeforeEach
    void setup() {
        service = new AppointmentService();
    }

    @Test
    void testAddAndDeleteAppointment() {
        Appointment a = new Appointment("001", new Date(System.currentTimeMillis() + 10000), "Test");
        service.addAppointment(a);
        assertEquals(a, service.getAppointmentById("001"));
        service.deleteAppointment("001");
        assertNull(service.getAppointmentById("001"));
    }

    @Test
    void testAddDuplicateIdThrowsException() {
        Appointment a = new Appointment("001", new Date(System.currentTimeMillis() + 10000), "Test");
        service.addAppointment(a);
        assertThrows(IllegalArgumentException.class, () -> service.addAppointment(a));
    }
}
