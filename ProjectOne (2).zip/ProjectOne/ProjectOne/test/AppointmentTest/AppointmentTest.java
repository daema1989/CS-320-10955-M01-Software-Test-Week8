package AppointmentTest;

import static org.junit.jupiter.api.Assertions.*;
import java.util.Date;
import org.junit.jupiter.api.Test;
import AppointmentService.Appointment;

public class AppointmentTest {
    @Test
    public void testValidAppointment() {
        Appointment a = new Appointment("001", new Date(System.currentTimeMillis() + 10000), "Description");
        assertEquals("001", a.getAppointmentId());
    }

    @Test
    public void testNullDescription() {
        assertThrows(IllegalArgumentException.class, () ->
            new Appointment("001", new Date(), null));
    }
}
