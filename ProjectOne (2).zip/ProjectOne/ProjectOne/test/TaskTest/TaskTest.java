package TaskTest;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import TaskService.Task;

public class TaskTest {
    @Test
    public void testValidTask() {
        Task task = new Task("101", "Title", "This is a task");
        assertEquals("101", task.getTaskId());
    }

    @Test
    public void testInvalidName() {
        assertThrows(IllegalArgumentException.class, () ->
            new Task("101", null, "desc"));
    }
}
