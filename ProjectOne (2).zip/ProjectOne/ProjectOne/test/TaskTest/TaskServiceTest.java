package TaskTest;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import TaskService.Task;
import TaskService.TaskService;

public class TaskServiceTest {
    private TaskService service;

    @BeforeEach
    void setup() {
        service = new TaskService();
    }

    @Test
    void testAddTask_validTask_addedSuccessfully() {
        Task task = new Task("101", "Name", "Desc");
        service.addTask(task);
        assertEquals(task, service.getTaskById("101"));
    }

    @Test
    void testAddTask_duplicateId_throwsException() {
        Task task = new Task("101", "Name", "Desc");
        service.addTask(task);
        assertThrows(IllegalArgumentException.class, () -> service.addTask(task));
    }
}
