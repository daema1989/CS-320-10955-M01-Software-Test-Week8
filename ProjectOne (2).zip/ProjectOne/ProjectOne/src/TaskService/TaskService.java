package TaskService;

import java.util.HashMap;
import java.util.Map;

public class TaskService {
    private final Map<String, Task> tasks = new HashMap<>();

    public void addTask(Task task) {
        if (tasks.containsKey(task.getTaskId()))
            throw new IllegalArgumentException("Task ID already exists.");
        tasks.put(task.getTaskId(), task);
    }

    public Task getTaskById(String taskId) {
        return tasks.get(taskId);
    }

    public void updateTask(Task task) {
        if (!tasks.containsKey(task.getTaskId()))
            throw new IllegalArgumentException("Task not found.");
        tasks.put(task.getTaskId(), task);
    }

    public void deleteTask(String taskId) {
        if (!tasks.containsKey(taskId))
            throw new IllegalArgumentException("Task not found.");
        tasks.remove(taskId);
    }
}
