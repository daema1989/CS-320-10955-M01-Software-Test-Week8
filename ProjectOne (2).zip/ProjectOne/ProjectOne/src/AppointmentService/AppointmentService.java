package AppointmentService;

import java.util.HashMap;
import java.util.Map;

public class AppointmentService {
    private final Map<String, Appointment> appointments = new HashMap<>();

    public void addAppointment(Appointment appt) {
        if (appointments.containsKey(appt.getAppointmentId()))
            throw new IllegalArgumentException("Duplicate ID");
        appointments.put(appt.getAppointmentId(), appt);
    }

    public void deleteAppointment(String id) {
        if (!appointments.containsKey(id))
            throw new IllegalArgumentException("Appointment not found");
        appointments.remove(id);
    }

    public Appointment getAppointmentById(String id) {
        return appointments.get(id);
    }
}
