package ContactService;

import java.util.HashMap;
import java.util.Map;
import java.util.NoSuchElementException;

public class ContactService {
    private final Map<String, Contact> contacts = new HashMap<>();

    public void addContact(Contact contact) {
        if (contacts.containsKey(contact.getContactId()))
            throw new IllegalArgumentException("Contact ID already exists.");
        contacts.put(contact.getContactId(), new Contact(
            contact.getContactId(), contact.getFirstName(), contact.getLastName(),
            contact.getPhone(), contact.getAddress()));
    }

    public Contact getContactById(String contactId) {
        Contact contact = contacts.get(contactId);
        if (contact == null) return null;
        return new Contact(contact.getContactId(), contact.getFirstName(),
                           contact.getLastName(), contact.getPhone(), contact.getAddress());
    }

    public void deleteContact(String contactId) {
        if (!contacts.containsKey(contactId))
            throw new NoSuchElementException("Contact not found.");
        contacts.remove(contactId);
    }

    public void updateContact(Contact updatedContact) {
        if (!contacts.containsKey(updatedContact.getContactId()))
            throw new NoSuchElementException("Contact not found.");
        contacts.put(updatedContact.getContactId(), new Contact(
            updatedContact.getContactId(), updatedContact.getFirstName(),
            updatedContact.getLastName(), updatedContact.getPhone(),
            updatedContact.getAddress()));
    }
}

